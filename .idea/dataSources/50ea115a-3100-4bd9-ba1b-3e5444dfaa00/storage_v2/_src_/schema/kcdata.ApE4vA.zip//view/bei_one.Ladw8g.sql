create definer = root@`%` view bei_one as
select `cl`.`classtype` AS `classtype`, `cl`.`classnumber` AS `classnumber`, `cl`.`percent` AS `percent`
from (`kcdata`.`class` `cl`
         join `kcdata`.`classdata` `cd` on ((`cl`.`classid` = `cd`.`id`)))
where (((`cl`.`classtype` = '北主楼') and (`cl`.`classnumber` = '201')) or
       ((`cl`.`classtype` = '北主楼') and (`cl`.`classnumber` = '202')) or
       ((`cl`.`classtype` = '北主楼') and (`cl`.`classnumber` = '203')) or
       ((`cl`.`classtype` = '北主楼') and (`cl`.`classnumber` = '204')));

